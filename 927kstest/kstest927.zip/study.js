this.name = "wwwwww";
function Demo() {
  this.name = "demo";
  this.fun = function () {
    console.log(this);
  };
  this.fn = () => {
    console.log(this);
  };
  this.fname = this.name;
}

var demo = new Demo();
demo.fun();
demo.fn();
demo.fname;
